package com.example.flutter_market

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
